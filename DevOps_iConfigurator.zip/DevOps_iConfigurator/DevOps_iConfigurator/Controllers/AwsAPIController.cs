﻿using DevOps_iConfigurator.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace DevOps_iConfigurator.Controllers
{
    public class AwsAPIController : ApiController
    {
        public static List<Attributes> CallPriceList()
        {
            WebClient n = new WebClient();
            var json = n.DownloadString(@"https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonEC2/current/ap-south-1/index.json");
            string Json = Convert.ToString(json);
            JavaScriptSerializer ser = new JavaScriptSerializer();
            ser.MaxJsonLength = Int32.MaxValue;
            var PriceList = ser.Deserialize<List<Models.Attributes>>(Json);
            return PriceList;
        }

        //public static List<Attributes> CallPriceList()
        //{
        //    string file = HttpContext.Current.Server.MapPath(<provide local path of json file>);
        //    //deserialize JSON from file  
        //    var Json = System.IO.File.ReadAllText(file);
        //    JavaScriptSerializer ser = new JavaScriptSerializer();
        //    ser.MaxJsonLength = Int32.MaxValue;
        //    var PriceList = ser.Deserialize<List<Models.Attributes>>(Json);
        //    return PriceList;
        //}
    }
}
