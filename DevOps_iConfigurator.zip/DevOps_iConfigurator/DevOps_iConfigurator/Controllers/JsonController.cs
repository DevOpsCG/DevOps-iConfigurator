﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DevOps_iConfigurator.Controllers
{
    public class JsonController : Controller
    {
        public ActionResult Index()
        {
            List<Models.Attributes> list = AwsAPIController.CallPriceList();
            return View(list);
        }
    }
}