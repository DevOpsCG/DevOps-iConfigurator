﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DevOps_iConfigurator.Models
{

    public class Rootobject
    {
        public _76V3SF2FJC3ZR3GH _76V3SF2FJC3ZR3GH { get; set; }
    }

    public class _76V3SF2FJC3ZR3GH
    {
        public string sku { get; set; }
        public string productFamily { get; set; }
        public Attributes attributes { get; set; }
    }

    public class Attributes
    {
        public string servicecode { get; set; }
        public string location { get; set; }
        public string locationType { get; set; }
        public string instanceType { get; set; }
        public string currentGeneration { get; set; }
        public string instanceFamily { get; set; }
        public string vcpu { get; set; }
        public string physicalProcessor { get; set; }
        public string clockSpeed { get; set; }
        public string memory { get; set; }
        public string storage { get; set; }
        public string networkPerformance { get; set; }
        public string processorArchitecture { get; set; }
        public string tenancy { get; set; }
        public string operatingSystem { get; set; }
        public string licenseModel { get; set; }
        public string usagetype { get; set; }
        public string operation { get; set; }
        public string ecu { get; set; }
        public string enhancedNetworkingSupported { get; set; }
        public string normalizationSizeFactor { get; set; }
        public string preInstalledSw { get; set; }
        public string processorFeatures { get; set; }
        public string servicename { get; set; }
    }

}