﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Mvc;
using System.Net.Http;
using System.Net.Http.Headers;


namespace DevOps_iConfigurator.Controllers
{
    public class DotNetQuestionsController : Controller
    {
        // GET: DotNetQuestions
        public ActionResult Index()
        {
            ViewBag.Message = "Select the application details...";
            return View();
        }

        public ActionResult UserDashBoard(string options)
        {
            //Session["Option"] = options;
            ViewBag.Message = options;
            QueueBuild();
            return View();
        }

        static void QueueBuild()
        {
            var personalaccesstoken = "vsx23xsue64upofi5xfv2cdkxolj5wbhz5xzjeb7vulkklsnmmcq";
       
            var base64Token = Convert.ToBase64String(Encoding.ASCII.GetBytes($":{personalaccesstoken}"));

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64Token);

                var requestMessage = new HttpRequestMessage(HttpMethod.Post, "https://selvans.visualstudio.com/DefaultCollection/Demo/_apis/build/builds?api-version=2.0");
                requestMessage.Content = new StringContent("{\"definition\": {\"id\":" + 4 + "},\"sourceBranch\":\"$/BRANCH_NAME\"}", Encoding.UTF8, "application/json");

                using (HttpResponseMessage response = client.SendAsync(requestMessage).Result)
                {
                    response.EnsureSuccessStatusCode();
                }
            }


         
        }
    }
}