﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DevOps_iConfigurator.Controllers
{
    public class DotNetImageController : Controller
    {
        // GET: DotNetImage
        public ActionResult Index()
        {
            return View();
        }
    }
}