﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DevOps_iConfigurator.Controllers
{
    public class JavaImageController : Controller
    {
        // GET: JavaImage
        public ActionResult Index()
        {
            return View();
        }
    }
}