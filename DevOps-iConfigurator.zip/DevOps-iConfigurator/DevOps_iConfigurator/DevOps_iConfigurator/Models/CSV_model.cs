﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DevOps_iConfigurator.Models
{
    public class CSV_model
    {
        public string Instance_Type { get; set; }
        public string OS_System { get; set; }
        public string Tenancy { get; set; }
        public string Price_per_Unit { get; set; }
        public string Unit { get; set; }
        public string Termtype { get; set; }
    }
}